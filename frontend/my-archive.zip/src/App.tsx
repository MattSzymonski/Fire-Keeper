import { StrictMode, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { HeroUIProvider } from '@heroui/react';
import DockerContainersStatus from './components/DockerContainersStatus';
import './style/global.css';
import logo from './assets/images/COTW_logo.png';

export default function App() {
  return (
    <>
      {/* Header bar with logo, always on top */}
      <header
        className="fixed top-0 left-0 w-full shadow z-50 flex items-center px-4 py-2"
        style={{ minHeight: '120px' }}
      >
        <img
          src={logo}
          alt="COTW Logo"
          className="mr-4"
          style={{ height: '110px', width: 'auto', objectFit: 'contain' }}
        />
      </header>
      {/* Main content with padding to avoid header overlap */}
      <div className="pt-16">
        <div className="p-4">
          <h1 className="mb-2">CONTAINERS</h1>
          <DockerContainersStatus />
        </div>
      </div>
    </>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <HeroUIProvider>
      <main className="dark text-foreground bg-background main-container">
        <App/>
      </main>
    </HeroUIProvider>
  </StrictMode>
);
